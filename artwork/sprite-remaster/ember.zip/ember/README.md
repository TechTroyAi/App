# EMBER TOWER - 1.4.3 sprite remaster (code-friendly contract)

Style (locked): flat 2D pixel art, strict bird's-eye top-down, medieval clockwork
forge-fantasy - charcoal iron, dark olive stone, muted brass, rivets/gears,
near-black outline, hard pixel clusters, NO 3D / perspective / bevels / gradients.
Single energy accent: ember orange.

## Files -> exact resource names
Copy the four game files into app/src/main/res/drawable-nodpi/ under these EXACT names
(SpriteCatalog.kt strings; a wrong name crashes at load):

| file in zip | resource name | loaded by |
|---|---|---|
| game/tower_ember_base.png | tower_ember_base | SpriteCatalog.load("tower_ember_base") |
| game/tower_ember_flame.png | tower_ember_flame | SpriteCatalog.loadStrip("tower_ember_flame") |
| game/projectile_ember.png | projectile_ember | SpriteCatalog.loadStrip("projectile_ember") |
| game/impact_ember.png | impact_ember | SpriteCatalog.loadStrip("impact_ember") |
| sources/*.png | - | raw AI sheets, reference/re-edit only, NOT code-referenced |

## Format rules
- Frames: 128x128 square; strips horizontal 384x128 (loadStrip needs width % height == 0,
  frameCount = width / height = 3). Renderer scales, no gameplay code changes.
- Background fully transparent; rotation pivot = exact frame centre in EVERY frame
  (verified <=1px drift by tools/sprite_contract_audit.py).
- turret order: [idle][fire, muzzle flash][recoil]; projectile/impact: 3-stage sequence.
- No baked backdrop, no text/labels/scenery. Do NOT add unreferenced resources
  (*_anim / *_strip names are not in SpriteCatalog).

## Re-editing: slice / transparency / resize
Regenerate from sources with:
  tools/remaster_process.py icon  <source.png> <out128.png>
  tools/remaster_process.py strip <sheet3.png> <out384x128.png>
then verify: tools/sprite_contract_audit.py <dir>  (must report 0 failures)
